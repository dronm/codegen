# Dronm Codegen documentation

- [Configuration and CLI](configuration.md) — commands, `codegen.yaml`, environment overrides, paths, and embedded templates.
- [Consumer integration](integration.md) — Go tool dependency, Make targets, workspace development, registry hooks, and CI.
- [Object schema reference](schema-reference.md) — complete YAML object contract and generated backend/frontend shape.
- [Migrating from an embedded generator](migration-from-embedded.md) — one-time extraction procedure for existing applications.
- [Releasing](releasing.md) — tagging, consumer upgrades, and compatibility guidance.
